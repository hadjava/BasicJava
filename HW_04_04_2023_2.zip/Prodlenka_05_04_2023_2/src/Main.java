import java.util.Scanner;

public class Main {
    //Проект 2. Используйте for.
    //Необходимо суммировать все нечётные целые числа в диапазоне, введённом
    // пользователем. Пользователь указывает нижнюю и верхнюю границу диапазона.
    public static void main(String[] args) {
        Scanner scr = new Scanner( System.in );
        System.out.println("wwedite dwa lubix tchisla: ");
        int a = scr.nextInt();
        int b = scr.nextInt();
        int sum = 0;

        for (int i = a; i <= b; i++) {
            if (i % 2 == 1) {
                sum += i;
            }
        }
        System.out.println( "Summa nechetix v diapasone" + a + "do " + b + "rawna" + sum );
    }
}