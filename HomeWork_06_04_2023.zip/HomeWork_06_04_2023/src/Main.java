/*
Homework_06_04_2023
 1 уровень сложности: 1 n - номер дома, в котором Вы живёте (без учёта дробей, корпусов, строений и т.д). Создайте массив целых чисел. Заполните массив числами от 0 до n*10, выведите массив в консоль.
2 Создайте случайно заполненный числовой массив, выведите его в консоль. Найдите максимальное по модулю число в массиве и выведите его в консоль.
3 Пользователь вводит строку. Разместите буквы в строке по алфавиту и выведите в консоль.
4 Пользователь вводит строку. Посчитайте количество слов в строке и выведите в консоль. Разделителем между словами считать только пробел. Если в строке есть слова, которые длиннее трёх символов, то вывести эти слова в консоль.

 */
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Задача 1
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите номер дома: ");
        int houseNumber = scanner.nextInt();

        int[] array = new int[houseNumber * 10 + 1];
        for (int i = 0; i < array.length; i++) {
            array[i] = i;
        }

        System.out.println(Arrays.toString(array));


        // Задача 2
        Random random = new Random();
        int[] randomArray = new int[10];
        for (int i = 0; i < randomArray.length; i++) {
            randomArray[i] = random.nextInt(100);
        }

        System.out.println(Arrays.toString(randomArray));

        int maxAbsoluteValue = findMaxAbsoluteValue(randomArray);
        System.out.println("Максимальное число по модулю: " + maxAbsoluteValue);


        // Задача 3
        scanner.nextLine(); // Сбросить символ новой строки после ввода числа в задаче 2
        System.out.print("Введите строку: ");
        String inputString = scanner.nextLine();

        char[] charArray = inputString.toCharArray();
        Arrays.sort(charArray);

        System.out.println("Строка по алфавиту: " + new String(charArray));


        // Задача 4
        int wordCount = countWords(inputString);
        System.out.println("Количество слов: " + wordCount);

        String[] words = inputString.split(" ");
        System.out.print("Слова длиннее трех символов: ");
        for (String word : words) {
            if (word.length() > 3) {
                System.out.print(word + " ");
            }
        }
    }

    public static int findMaxAbsoluteValue(int[] array) {
        int maxAbsoluteValue = Integer.MIN_VALUE;
        for (int value : array) {
            int absoluteValue = Math.abs(value);
            if (absoluteValue > maxAbsoluteValue) {
                maxAbsoluteValue = absoluteValue;
            }
        }
        return maxAbsoluteValue;
    }

    public static int countWords(String inputString) {
        String[] words = inputString.trim().split("\\s+");
        return words.length;
    }
}
