import java.util.Scanner;

public class Main {
    enum Snack {
        CHOCOLATE("Шоколадка"),
        CHIPS("Чипсы"),
        CANDY("Конфеты"),
        COOKIES("Печенье");

        private String name;

        Snack(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите номер снека: ");
        int snackNumber = scanner.nextInt();

        Snack selectedSnack = null;

        switch (snackNumber) {
            case 1:
                selectedSnack = Snack.CHOCOLATE;
                break;
            case 2:
                selectedSnack = Snack.CHIPS;
                break;
            case 3:
                selectedSnack = Snack.CANDY;
                break;
            case 4:
                selectedSnack = Snack.COOKIES;
                break;
            default:
                System.out.println("Некорректный номер снека");
        }

        if (selectedSnack != null) {
            System.out.println("Выбранный снек: " + selectedSnack.getName());
        }
    }
}