public class Main implements Cloneable {
    private String name;
    private String group;

    public Main(String name) {
        this.name = name;
    }

    public Main(String name, String group) {
        this(name); // делегирование инициализации имени в конструкторе
        this.group = group;
    }

    public Main(Main other) {
        this.name = other.name;
        this.group = other.group;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public static void main(String[] args) {
        Main student1 = new Main("John");
        Main student2 = student1;

        Main student3 = null;
        try {
            student3 = (Main) student1.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        student1.setName("Alice");

        System.out.println("Student 1: " + student1.getName() + " " + student1.getGroup());
        System.out.println("Student 2: " + student2.getName() + " " + student2.getGroup());
        System.out.println("Student 3: " + student3.getName() + " " + student3.getGroup());
    }
}