import java.util.Scanner;

class WeddingAnniversary {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество лет в браке: ");
        int yearsMarried = scanner.nextInt();

        String[] anniversaries = {
                "Бумажная", "Ситцевая", "Хрустальная", "Фарфоровая", "Деревянная",
                "Свинцовая", "Медная", "Оловянная", "Бронзовая", "Стальная",
                "Нефтяная", "Шерстяная", "Льняная", "Кружевная", "Хлопковая"
        };

        int index = yearsMarried % anniversaries.length;
        String anniversary = anniversaries[index];

        System.out.println("Следующая годовщина свадьбы будет " + anniversary);
    }
}