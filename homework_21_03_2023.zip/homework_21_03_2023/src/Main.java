



/* 1 уровень сложности: Можно сделать оба задания в одном проекте.
1 Напишите метод, который принимает три строки и строку-разделитель. Метод
возвращает единую строку, состоящую из исходных строк, разделённых строкой-разделителем.
Например, на входе "один", "два", "три", "|". На выходе: "один|два|три"
2 Напишите метод, который выводит в консоль первый символ переданной в него строки.
*/

    class StringManipulation {

        // Метод, объединяющий строки с использованием разделителя
        public static String concatenateStrings(String str1, String str2, String str3, String delimiter) {
            StringBuilder sb = new StringBuilder();
            sb.append(str1).append(delimiter).append(str2).append(delimiter).append(str3);
            return sb.toString();
        }

        // Метод, выводящий первый символ переданной строки в консоль
        public static void printFirstChar(String str) {
            if (str != null && !str.isEmpty()) {
                System.out.println("Первый символ: " + str.charAt(0));
            } else {
                System.out.println("Строка пуста!");
            }
        }

        public static void main(String[] args) {
            String str1 = "один";
            String str2 = "два";
            String str3 = "три";
            String delimiter = "|";

            // Вызов метода для объединения строк
            String result = concatenateStrings(str1, str2, str3, delimiter);
            System.out.println("Объединение строк: " + result);

            String str = "HADJAVA";
            // Вызов метода для вывода первого символа строки
            printFirstChar(str);
        }
    }
