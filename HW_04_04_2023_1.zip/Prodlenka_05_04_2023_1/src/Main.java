import java.util.Random;

public class Main {
    // 1 уровень сложности: Проект 1. Используйте while:
    //Напиши программу, которая моделирует ситуацию.
    //Ты попросил друзей скинуться на подарок на твой День Рождения. Каждый друг случайным
    // образом может подарить тебе одну купюру номиналом 500, 1000, 2000 или 5000 рублей.
    // Твоя цель - новенький игровой ПК, который стоит 100 000 рублей.
    //Как только друзья подарят тебе нужную сумму (или даже чуть больше), останавливай сбор
    // подарков и веди всех выпить за твоё здоровье в лучший бар города!

    public static void main(String[] args) {
        int total = 0;
        int finalAmount = 100000;
        Random rnd = new Random();
        while (total < finalAmount){
            System.out.println("Sobrannaya summa na dannyi moment: " + total);
            int a = 0;
            int randomNumber = rnd.nextInt(3);
            switch (randomNumber){
                case 0:
                    a = 500;
                    break;
                case 1:
                    a = 1000;
                    break;
                case 2:
                    a = 2000;
                    break;
                case 3:
                    a = 5000;
                    break;

            }
            total += a;

        }
        System.out.println("druzia sobrali summu: " + total + "rublei");
    }
}