import java.util.Scanner;
import java.util.Random;
    public class Main {
  /*
   Все задания можно выполнить в одном проекте.
1 Пользователь вводит число. Если число больше 0, то выполнить следующие операции:


умножить число на 2, если оно нечётное;

прибавить к числу 5, если если оно заканчивается на 5 или 0.
Если число < 0, то взять его по модулю и разделить на 3.
Результат вычисления вывести в консоль.


2 Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9),
то вывести эту цифру в консоль. Если строка начинается со знака _ или знака -, то вывести в консоль
строку без этого знака. Используйте методы startsWith, charAt и substring.


3 Пользователь вводит два числа. Если они не равны, то вывести в консоль их сумму, иначе вывести
их произведение. Используйте тернарный оператор.


4 С помощью Random сгенерируйте три числа. Напишите программу, которая находит максимальное из них. Используйте
 тернарные операторы.
   */

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            // Задание 1
            System.out.print("Введите число: ");
            int number = scanner.nextInt();
            if (number > 0) {
                if (number % 2 != 0) {
                    number *= 2;
                }
                if (number % 10 == 5 || number % 10 == 0) {
                    number += 5;
                }
            } else {
                number = Math.abs(number) / 3;
            }
            System.out.println("Результат: " + number);

            // Задание 2
            scanner.nextLine(); 
            System.out.print("Введите строку: ");
            String inputString = scanner.nextLine();
            if (inputString.length() > 0) {
                char firstChar = inputString.charAt(0);
                if (Character.isDigit(firstChar)) {
                    System.out.println("Первая цифра: " + firstChar);
                } else if (firstChar == '_' || firstChar == '-') {
                    System.out.println("Строка без первого символа: " + inputString.substring(1));
                }
            }

            // Задание 3
            System.out.print("Введите первое число: ");
            int num1 = scanner.nextInt();
            System.out.print("Введите второе число: ");
            int num2 = scanner.nextInt();
            int result = (num1 != num2) ? (num1 + num2) : (num1 * num2);
            System.out.println("Результат: " + result);

            // Задание 4
            Random random = new Random();
            int num3 = random.nextInt();
            int max = (num1 > num2) ? ((num1 > num3) ? num1 : num3) : ((num2 > num3) ? num2 : num3);
            System.out.println("Максимальное число: " + max);
        }
    }